package me.pm.nm_software.dojocis.modernjava.model;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class DataEntryTest
{
    private static DataEntry entry;

    @BeforeAll
    public static void setup()
    {
        entry = DataEntry.fromString("XXX;ABCD;0.0;1.0;2.0;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;1234.5678");
    }

    @Test
    public void requesting_a_year_before_1960_should_throw_exception()
    {
        assertThrows(IllegalArgumentException.class, () -> entry.valueForYear(1920));
    }

    @Test
    public void requesting_a_year_after_2022_should_throw_exception()
    {
        assertThrows(IllegalArgumentException.class, () -> entry.valueForYear(2023));
    }

    @Test
    public void requesting_a_year_with_no_data_returns_an_empty_optional()
    {
        assertTrue(entry.valueForYear(1980).isEmpty());
    }

    @Test
    public void requesting_a_year_with_data_returns_a_value()
    {
        assertTrue(entry.valueForYear(1960).isPresent());
        assertEquals(0.0, entry.valueForYear(1960).getAsDouble());
    }
}