package me.pm.nm_software.dojocis.modernjava.streams;

import me.pm.nm_software.dojocis.modernjava.model.AbsoluteType;
import me.pm.nm_software.dojocis.modernjava.model.Country;
import me.pm.nm_software.dojocis.modernjava.model.PercentageType;

import java.util.Arrays;
import java.util.Map;
import java.util.OptionalDouble;

public class Exercises
{

    public static void runStreamExercises()
    {
        // TODO #001 - Group countries by income group and display LOW sorted by name
        printHeader("Exercise 001");

        // Implement method in DataMiner
        //var groups = DataMiner.groupByIncome();

        // Get, sort and print
        System.out.println("Not implemented yet");

        printFooter();

        // TODO #002 - Count the number of countries by income group
        printHeader("Exercise 002");

        final Map<Country.IncomeGroup, Long> groupCounts = DataMiner.incomeGroupCount();


        // Print


        printFooter();

        // TODO #003 - Find the inflation values for France and print for each year.
        printHeader("Exercice 003");

        var inflationInFrance = DataMiner.getData("FRA", "FP.CPI.TOTL.ZG").orElseThrow();


        // Print years between 1960 & 2022

        printFooter();

        // TODO #004 - Compute cumulative inflation between two years.
        printHeader("Exercice 004");

        record YearSpan(int from, int to)
        {

        }

        // 1960 to 2022 / 2001 to 2022 / 2011 to 2022 / 2019 to 2022


        // Use DataMiner.computeCumulativePercentage

        printFooter();


        // TODO #005 - Retrieve the CO2 Emissions in France and compute some statistics (min / max / mean ... )
        printHeader("Exercice 005");

        final var co2 = DataMiner
                .getData("FRA", "EN.ATM.CO2E.KT")
                .orElseThrow();

         // System.out.println("CO2 stats = " + stats);

        printFooter();

        // TODO #006 - Retrieve the year of max emission
        printHeader("Exercice 006");

        record YearVal(int year, double val)
        {

        }

        var max = "" ;

        System.out.println("Maximal CO2 emission = " + max);

        printFooter();

        // TODO #007 - Implement PercentageType

        // TODO #008 - Implement AbsoluteType

        // TODO #009 - Use them to compute cumulative values.

        printHeader("Exercice 007, 008, 009");

        var totalCO2 = DataMiner.computeCumulativeValue(
                co2, new AbsoluteType(), 1960, 2022);

        System.out.println("totalCO2 = " + totalCO2);

        var cumulativeInflation = DataMiner.computeCumulativeValue(
                inflationInFrance, new PercentageType(),
                1960, 2022);

        System.out.println("cumulativeInflation = " + cumulativeInflation);

        printFooter();
    }


    public static void runStreamUtilsExercices()
    {
        // TODO #010 - Find the highest inflation rise between two consecutive years in France

        printHeader("Exercice 010");

        var inflation = DataMiner.getData("FRA", "FP.CPI.TOTL.ZG").orElseThrow();


        // Filter out empty value and keep stream of Double
        // final Stream<Double> values = Arrays.stream(inflation.values()) ...

        // final OptionalDouble max = StreamsUtils. .../...

        // System.out.println("Max inflation increase= " + max);

        printFooter();

        // TODO #011 - Display percentage of CO2 for France compared to world total.

        printHeader("Exercice 011");

        final var fraCO2 = Arrays.stream(DataMiner
                        .getData("FRA", "EN.ATM.CO2E.KT")
                        .orElseThrow().values())
                .filter(OptionalDouble::isPresent)
                .map(OptionalDouble::getAsDouble);

        final var wldCO2 = Arrays.stream(DataMiner
                        .getData("WLD", "EN.ATM.CO2E.KT")
                        .orElseThrow().values())
                .filter(OptionalDouble::isPresent)
                .map(OptionalDouble::getAsDouble);

        // Data for CO2 start at year 1990

        // StreamsUtils. .../...

        printFooter();

    }

    private static void printHeader(String name)
    {
        System.out.println(" ### --- ############ --- ### ");
        System.out.println(" ### --- " + name + " --- ### ");
        System.out.println(" ### --- ############ --- ### ");
        System.out.println();
    }

    private static void printFooter()
    {
        System.out.println();
        System.out.println(" ### --- ############ --- ### ");
        System.out.println();
    }
}
