package me.pm.nm_software;

import me.pm.nm_software.dojocis.modernjava.streams.Exercises;

public class Main
{
    public static void main(String[] args)
    {
        Exercises.runStreamExercises();

        Exercises.runStreamUtilsExercices();
    }

}