package me.pm.nm_software.dojocis.modernjava.model;

import java.text.NumberFormat;
import java.text.ParseException;
import java.util.Arrays;
import java.util.Locale;
import java.util.OptionalDouble;

/**
 *
 * @param countryCode
 * @param indicatorCode
 * @param values
 */
public record DataEntry(String countryCode,
                        String indicatorCode,
                        OptionalDouble[] values)
{
    private static final NumberFormat FORMAT = NumberFormat.getInstance(Locale.FRANCE);

    public OptionalDouble valueForYear(int year)
    {
        if (year < 1960 || year > 2022)
        {
            throw new IllegalArgumentException(
                    String.format("Year %d is out [1960,2022] bounds", year));
        }

        if( year - 1960 >= values.length)
        {
            return OptionalDouble.empty();
        }

        return values[year - 1960];
    }

    public static DataEntry fromString(String rawString)
    {
        var parts = rawString.split(";");

        var values = Arrays.stream(parts)
                .skip(2)
                .map(DataEntry::parseDouble)
                .toArray(OptionalDouble[]::new);

        return new DataEntry(parts[0], parts[1], values);
    }

    private static OptionalDouble parseDouble(String ds)
    {
        if (ds.isEmpty())
        {
            return OptionalDouble.empty();
        }
        try
        {
            return OptionalDouble.of(FORMAT.parse(ds).doubleValue());
        }
        catch (ParseException e)
        {
            return OptionalDouble.empty();
        }
    }
}
