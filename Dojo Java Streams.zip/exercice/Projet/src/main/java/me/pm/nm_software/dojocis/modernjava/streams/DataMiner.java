package me.pm.nm_software.dojocis.modernjava.streams;

import me.pm.nm_software.dojocis.DataStore;
import me.pm.nm_software.dojocis.modernjava.model.Country;
import me.pm.nm_software.dojocis.modernjava.model.DataEntry;
import me.pm.nm_software.dojocis.modernjava.model.DataType;

import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * Utility class providing methods to analyse the data set.
 */
public final class DataMiner
{
    private DataMiner()
    {

    }

    public static Map<Country.IncomeGroup, List<Country>> groupByIncome()
    {
        throw new UnsupportedOperationException("Not implemented yet");
    }

    public static Map<Country.IncomeGroup, Long> incomeGroupCount()
    {
        throw new UnsupportedOperationException("Not implemented yet");
    }


    public static Optional<DataEntry> getData(
            String countryCode, String indicatorCode)
    {
        return DataStore.INSTANCE.getData().stream()
                .filter(de -> de.countryCode().equals(countryCode))
                .filter(de -> de.indicatorCode().equals(indicatorCode))
                .findFirst();
    }

    public static double computeCumulativePercentage(
            DataEntry entry, int fromYear, int toYear)
    {
        throw new UnsupportedOperationException("Not implemented yet");
    }

    public static double computeCumulativeValue(DataEntry entry,
                                                DataType type,
                                                int fromYear, int toYear)
    {
        throw new UnsupportedOperationException("Not implemented yet");
    }

}
