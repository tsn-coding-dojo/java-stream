package me.pm.nm_software.dojocis.modernjava.model;

import java.util.function.DoubleBinaryOperator;
import java.util.function.DoubleUnaryOperator;

public non-sealed class AbsoluteType implements DataType
{

    @Override
    public DoubleUnaryOperator normalizer()
    {
        throw new UnsupportedOperationException("Not implemented yet");
    }

    @Override
    public DoubleBinaryOperator reducer()
    {
        throw new UnsupportedOperationException("Not implemented yet");
    }

    @Override
    public double identityElement()
    {
        throw new UnsupportedOperationException("Not implemented yet");
    }
}
