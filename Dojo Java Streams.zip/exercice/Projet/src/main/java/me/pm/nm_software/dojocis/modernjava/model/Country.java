package me.pm.nm_software.dojocis.modernjava.model;

/**
 * Record used to model a country entry of the WDI data set
 *
 * @param code     country code
 * @param name     short name of the country
 * @param currency currency used in the country
 * @param region   world region the country is considered in
 * @param income   income group of the country
 */
public record Country(String code,
                      String name,
                      String currency,
                      String region,
                      IncomeGroup income)
{


    /**
     * Creates a <code>Country</code> from an input string.
     *
     * @param rawString the input data
     * @return a country instance matching input string
     */
    public static Country fromString(String rawString)
    {
        var parts = rawString.split(";");

        return new Country(
                parts[0], parts[1], parts[2], parts[3],
                IncomeGroup.fromString(parts[4]));
    }

    /**
     * Enumeration of the different income groups considered in the WDI data set.
     */
    public enum IncomeGroup
    {
        HIGH,
        UPPER_MIDDLE,
        LOWER_MIDDLE,
        LOW,
        NOT_AVAILABLE;

        public static IncomeGroup fromString(String s)
        {
            if (s.contains("High"))
            {
                return HIGH;
            }
            else if (s.contains("Upper"))
            {
                return UPPER_MIDDLE;
            }
            else if (s.contains("Lower"))
            {
                return LOWER_MIDDLE;
            }
            else if (s.contains("Low"))
            {
                return LOW;
            }

            return NOT_AVAILABLE;
        }

    }
}
