Toutes les dépendances sont dans le répertoire .m2

Vous pouvez-aussi configurer le fichier EXEMPLE settings.xml et le renommé en settings.xml pour accéder à l'artifcatory de la TDF.

/!\ DEMANDE UN COMPTE TDF & ENROLLEMENT A L'INNER SOURCE : L'UTILISATION DE LA TDF POUR DES PROJETS NON INNERSOURCE PEUT ENTRAINER DES FACTURATIONS !


/!\ Léger souci avec l'artificatory de la TDF / maven et IntelliJ => On ne peut pas lancer de TU à cause de :

Could not transfer artifact org.eclipse.aether:aether-util:jar:1.0.0.v20140518 from/to central (https://artifactory.thalesdigital.io/artifactory/mvn): authorization failed for https://artifactory.thalesdigital.io/artifactory/mvn/org/eclipse/aether/aether-util/1.0.0.v20140518/aether-util-1.0.0.v20140518.jar, status: 403 TIEReputation

(J'ai mal à mon craft, mais je vais essayer de comprendre...)