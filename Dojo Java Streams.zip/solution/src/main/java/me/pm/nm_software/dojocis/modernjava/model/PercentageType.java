package me.pm.nm_software.dojocis.modernjava.model;

import java.util.function.DoubleBinaryOperator;
import java.util.function.DoubleUnaryOperator;

public final class PercentageType implements DataType
{
    @Override
    public DoubleUnaryOperator normalizer()
    {
        return d -> 1 + (d / 100.0);
    }

    @Override
    public DoubleBinaryOperator reducer()
    {
        return (a, b) -> a * b;
    }

    @Override
    public double identityElement()
    {
        return 1;
    }
}
