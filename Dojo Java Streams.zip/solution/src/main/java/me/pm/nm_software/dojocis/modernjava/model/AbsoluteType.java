package me.pm.nm_software.dojocis.modernjava.model;

import java.util.function.DoubleBinaryOperator;
import java.util.function.DoubleUnaryOperator;

public non-sealed class AbsoluteType implements DataType
{

    @Override
    public DoubleUnaryOperator normalizer()
    {
        return d -> d;
    }

    @Override
    public DoubleBinaryOperator reducer()
    {
        return Double::sum;
    }

    @Override
    public double identityElement()
    {
        return 0;
    }
}
