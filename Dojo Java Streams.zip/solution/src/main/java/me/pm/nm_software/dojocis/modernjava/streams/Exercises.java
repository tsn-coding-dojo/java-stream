package me.pm.nm_software.dojocis.modernjava.streams;

import me.pm.nm_software.dojocis.modernjava.model.AbsoluteType;
import me.pm.nm_software.dojocis.modernjava.model.Country;
import me.pm.nm_software.dojocis.modernjava.model.PercentageType;
import org.paumard.streams.StreamsUtils;

import java.util.Arrays;
import java.util.Comparator;
import java.util.DoubleSummaryStatistics;
import java.util.Map;
import java.util.OptionalDouble;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class Exercises
{

    public static void runStreamExercises()
    {
        // TODO #001 - Group countries by income group and display LOW sorted by name
        printHeader("Exercise 001");

        var groups = DataMiner.groupByIncome();

        groups.get(Country.IncomeGroup.LOW).stream()
                .sorted(Comparator.comparing(Country::name))
                .forEach(System.out::println);

        printFooter();

        // TODO #002 - Count the number of countries by income group
        printHeader("Exercise 002");

        final Map<Country.IncomeGroup, Long> groupCounts = DataMiner.incomeGroupCount();

        groupCounts.forEach(
                (group, count) -> System.out.printf("Group %s contains %d countries%n", group, count));

        printFooter();

        // TODO #003 - Find the inflation values for France and print for each year.
        printHeader("Exercice 003");

        var inflationInFrance = DataMiner.getData("FRA", "FP.CPI.TOTL.ZG").orElseThrow();


        IntStream.rangeClosed(1960, 2022)
                .forEach(i -> System.out.printf("Year %d : %s%n", i, inflationInFrance.valueForYear(i)));

        printFooter();

        // TODO #004 - Compute cumulative inflation between years.
        printHeader("Exercice 004");

        record YearSpan(int from, int to)
        {

        }

        var spans = Stream.of(new YearSpan(1960, 2022), new YearSpan(2001, 2022), new YearSpan(2011, 2022), new YearSpan(2019, 2022));

        spans.forEach(ys -> System.out.printf(
                "Cumulative inflation between %d and %d = %f%n", ys.from, ys.to, DataMiner.computeCumulativePercentage(inflationInFrance, ys.from, ys.to)
        ));

        printFooter();


        // TODO #005 - Retrieve the CO2 Emissions in France and compute some statistics
        printHeader("Exercice 005");

        final var co2 = DataMiner
                .getData("FRA", "EN.ATM.CO2E.KT")
                .orElseThrow();

        final DoubleSummaryStatistics stats =
                Arrays.stream(co2.values())
                        .filter(OptionalDouble::isPresent)
                        .mapToDouble(OptionalDouble::getAsDouble)
                        .summaryStatistics();

        System.out.println("CO2 stats = " + stats);

        printFooter();

        // TODO #006 - Retrieve the year of max emission
        printHeader("Exercice 006");

        record YearVal(int year, double val)
        {

        }

        var max = IntStream.rangeClosed(1960, 2022)
                .mapToObj(i -> new YearVal(i, co2.valueForYear(i).orElse(0)))
                .reduce((y1, y2) -> y1.val > y2.val ? y1 : y2);

        System.out.println("Maximal CO2 emission = " + max);

        printFooter();

        // TODO #007 - Implement PercentageType

        // TODO #008 - Implement AbsoluteType

        // TODO #009 - Use them to compute cumulative values.

        printHeader("Exercice 007, 008, 009");

        var totalCO2 = DataMiner.computeCumulativeValue(
                co2, new AbsoluteType(), 1960, 2022);

        System.out.println("totalCO2 = " + totalCO2);

        var cumulativeInflation = DataMiner.computeCumulativeValue(
                inflationInFrance, new PercentageType(),
                1960, 2022);

        System.out.println("cumulativeInflation = " + cumulativeInflation);

        printFooter();
    }


    public static void runStreamUtilsExercices()
    {
        // TODO #010 - Find the highest inflation rise between two consecutive years in France

        printHeader("Exercice 010");

        var inflation = DataMiner.getData("FRA", "FP.CPI.TOTL.ZG").orElseThrow();


        // Filter out empty value and keep stream of Double
        final Stream<Double> values = Arrays.stream(inflation.values())
                .filter(OptionalDouble::isPresent)
                .map(OptionalDouble::getAsDouble);

        final OptionalDouble max = StreamsUtils.roll(values, 2)
                .mapToDouble(g -> g.reduce(0.0, (a, b) -> b - a))
                .max();

        System.out.println("Max inflation increase= " + max);

        printFooter();

        // TODO #011 - Display percentage of CO2 for France compared to world total.

        printHeader("Exercice 011");

        final var fraCO2 = Arrays.stream(DataMiner
                        .getData("FRA", "EN.ATM.CO2E.KT")
                        .orElseThrow().values())
                .filter(OptionalDouble::isPresent)
                .map(OptionalDouble::getAsDouble);

        final var wldCO2 = Arrays.stream(DataMiner
                        .getData("WLD", "EN.ATM.CO2E.KT")
                        .orElseThrow().values())
                .filter(OptionalDouble::isPresent)
                .map(OptionalDouble::getAsDouble);

        // Data for CO2 start at year 1990

        StreamsUtils.zip(IntStream.iterate(1990, i -> i+1).boxed(),
                        StreamsUtils.zip(wldCO2, fraCO2, (w, f) -> f / w * 100),
                        (year,val) -> String.format("%d : %.2f %%", year,val))
                .forEach(System.out::println);

        printFooter();

    }

    private static void printHeader(String name)
    {
        System.out.println(" ### --- ############ --- ### ");
        System.out.println(" ### --- " + name + " --- ### ");
        System.out.println(" ### --- ############ --- ### ");
        System.out.println();
    }

    private static void printFooter()
    {
        System.out.println();
        System.out.println(" ### --- ############ --- ### ");
        System.out.println();
    }
}
