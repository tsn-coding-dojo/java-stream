package me.pm.nm_software.dojocis.modernjava.model;

// Series Code;Topic;Indicator Name;Unit of measure
public record Series(String code, String topic, String indicator, String unit)
{

    public static Series fromString(String rawString)
    {
        var parts = rawString.split(";");

        return new Series(parts[0], parts[1], parts[2], parts[3]);
    }
}
