package me.pm.nm_software.dojocis.modernjava.streams;

import me.pm.nm_software.dojocis.DataStore;
import me.pm.nm_software.dojocis.modernjava.model.Country;
import me.pm.nm_software.dojocis.modernjava.model.DataEntry;
import me.pm.nm_software.dojocis.modernjava.model.DataType;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.OptionalDouble;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

/**
 * Utility class providing methods to analyse the data set.
 */
public final class DataMiner
{
    private DataMiner()
    {

    }

    public static Map<Country.IncomeGroup, List<Country>> groupByIncome()
    {
        return DataStore.INSTANCE.getCountries().stream()
                .collect(Collectors.groupingBy(Country::income));
    }

    public static Map<Country.IncomeGroup, Long> incomeGroupCount()
    {
        return DataStore.INSTANCE.getCountries().stream()
                .collect(Collectors.groupingBy(Country::income, Collectors.counting()));
    }


    public static Optional<DataEntry> getData(
            String countryCode, String indicatorCode)
    {
        return DataStore.INSTANCE.getData().stream()
                .filter(de -> de.countryCode().equals(countryCode))
                .filter(de -> de.indicatorCode().equals(indicatorCode))
                .findFirst();
    }

    public static double computeCumulativePercentage(
            DataEntry entry, int fromYear, int toYear)
    {
        return IntStream.rangeClosed(fromYear, toYear)
                .mapToObj(entry::valueForYear)
                .filter(OptionalDouble::isPresent)
                .mapToDouble(OptionalDouble::getAsDouble)
                .map(d -> 1 + (d / 100.0))
                .reduce(1, (a, b) -> a * b);
    }

    public static double computeCumulativeValue(DataEntry entry,
                                                DataType type,
                                                int fromYear, int toYear)
    {
        return IntStream.rangeClosed(fromYear, toYear)
                .mapToObj(entry::valueForYear)
                .filter(OptionalDouble::isPresent)
                .mapToDouble(OptionalDouble::getAsDouble)
                .map(type.normalizer())
                .reduce(type.identityElement(), type.reducer());

    }

}
