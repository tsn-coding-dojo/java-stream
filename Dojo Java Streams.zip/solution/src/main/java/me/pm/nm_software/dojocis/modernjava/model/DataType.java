package me.pm.nm_software.dojocis.modernjava.model;

import java.util.function.DoubleBinaryOperator;
import java.util.function.DoubleUnaryOperator;

public sealed interface DataType permits AbsoluteType, PercentageType
{
   DoubleUnaryOperator normalizer();

   DoubleBinaryOperator reducer();

   double identityElement();
}
