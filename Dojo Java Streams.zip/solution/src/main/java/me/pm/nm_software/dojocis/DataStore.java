package me.pm.nm_software.dojocis;

import me.pm.nm_software.dojocis.modernjava.model.Country;
import me.pm.nm_software.dojocis.modernjava.model.DataEntry;
import me.pm.nm_software.dojocis.modernjava.model.Series;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Collection;
import java.util.Collections;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * Singleton used to store parsed data for performance reasons, a kind of cache.
 */
public enum DataStore
{
    INSTANCE;

    private Collection<Country> countries;

    private Collection<DataEntry> data;

    private Collection<Series> series;

    /**
     * Retrieve the list of countries in the WDI data set.
     * Groups are excluded.
     *
     * @return a collection of <code>{@link Country}</code>
     */
    public Collection<Country> getCountries()
    {
        if(Objects.isNull(countries))
        {
            countries = parseCountries();
        }

        return countries;
    }

    private Collection<Country> parseCountries()
    {
        try( var lines = Files.lines(Path.of("./data/Countries.csv")))
        {
            return lines.skip(1) // First line is column names
                    // No income group means not a country but a grouping
                    .filter(s -> s.charAt(s.length() - 1) != ';')
                    .map(Country::fromString)
                    .collect(Collectors.toSet());

        }
        catch (IOException e)
        {
            e.printStackTrace();
            return Collections.emptySet();
        }
    }

    /**
     * Retrieve the list of series in the WDI data set.
     * @return a collection of <code>{@link Series}</code>
     */
    public Collection<Series> getSeries()
    {
        if( Objects.isNull(series))
        {
            series = parseSeries();
        }

        return series;
    }

    private Collection<Series> parseSeries()
    {
        try( var lines = Files.lines(Path.of("./data/Series.csv")))
        {
            return lines.skip(1) // First line is column names
                    .map(Series::fromString)
                    .toList();
        }
        catch (IOException e)
        {
            e.printStackTrace();
            return Collections.emptyList();
        }
    }

    /**
     * Retrieve the whole parsed set of data values in the WDI data set.
     * @return a collection of <code>{@link DataEntry}</code>
     */
    public Collection<DataEntry> getData()
    {
        if( Objects.isNull(data))
        {
            data = parseData();
        }

        return data;
    }

    private Collection<DataEntry> parseData()
    {
        try( var lines = Files.lines(Path.of("./data/Data.csv")))
        {
            return lines.skip(1) // First line is column names
                    .map(DataEntry::fromString)
                    .toList();
        }
        catch (IOException e)
        {
            e.printStackTrace();
            return Collections.emptyList();
        }
    }
}
