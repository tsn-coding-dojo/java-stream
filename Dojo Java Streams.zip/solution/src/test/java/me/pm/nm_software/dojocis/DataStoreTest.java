package me.pm.nm_software.dojocis;

import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class DataStoreTest
{

    private static final int COUNTRIES_NUMBER = 217;

    private static final int SERIES_NUMBER = 1486;

    private static final int DATA_ROWS = 395276;

    @Test
    @Tag("Data:Size")
    void should_return_the_right_number_of_countries()
    {
        assertEquals(COUNTRIES_NUMBER,
                DataStore.INSTANCE.getCountries().size());
    }
}