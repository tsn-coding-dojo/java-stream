package me.pm.nm_software.dojocis.modernjava.streams;

import me.pm.nm_software.dojocis.DataStore;
import me.pm.nm_software.dojocis.modernjava.model.Country;
import me.pm.nm_software.dojocis.modernjava.model.DataEntry;
import org.junit.jupiter.api.Test;

import java.util.Collection;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class DataMinerTest
{
    @Test
    public void should_find_FRA_in_countries()
    {
        // FRA;France;Euro;Europe & Central Asia;High income
        Country france =
                new Country("FRA", "France", "Euro",
                        "Europe & Central Asia",
                        Country.IncomeGroup.HIGH);

        final Collection<Country> countries = DataStore.INSTANCE.getCountries();


        assertTrue(countries.contains(france));
    }

    @Test
    public void should_find_expected_item_in_income_group()
    {
        var groupsMap = DataMiner.groupByIncome();

        var naList = groupsMap.get(Country.IncomeGroup.NOT_AVAILABLE);

        assertEquals(1, naList.size());

        assertEquals(naList.get(0).code(), "VEN");
    }

    @Test
    public void should_correctly_find_inflation_in_a_country()
    {
        final Optional<DataEntry> inflationFR =
                DataMiner.getData("FRA", "FP.CPI.TOTL.ZG");

        assertTrue(inflationFR.isPresent());
        assertEquals(0.037514380512518, inflationFR.get().valueForYear(2015).getAsDouble());
    }

    @Test
    public void cumulative_inflation_is_correctly_computed()
    {
        final DataEntry entry =
                DataEntry.fromString("TST;TST;10;10;10;10;10");

        final double v = DataMiner.computeCumulativePercentage(entry, 1960, 1964);

        assertEquals(Math.pow(1.1, 5), v, 0.001);
    }
}